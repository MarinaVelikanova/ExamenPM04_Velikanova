﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VelikanovaMarina
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[a-zA-Za-яА-Я\\s]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        

        
        private void TextBox3_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (textBox3.Text.Length < 10 || textBox3.Text.Length > 50)
            {
                MessageBox.Show("Некорректнаяулица!");
                textBox3.Focus();
            }
            else
            {
                MessageBox.Show("Улица: " + textBox3.Text);
            }


        }

        private void textBox2_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (textBox2.Text.Length < 2 || textBox2.Text.Length > 25)
            {
                MessageBox.Show("Некорректныйгород!");
                textBox2.Focus();
            }
            else
            {
                MessageBox.Show("Город: " + textBox2.Text);
            }

        }
    }
 }

